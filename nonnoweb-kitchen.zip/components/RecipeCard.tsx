import React, { useState, useEffect, useRef } from 'react';
import { RecipeResponse } from '../types';
import { 
  Wine, Clock, ChefHat, Sparkles, Download, Printer, ArrowLeft, 
  Play, Pause, RotateCcw, CheckCircle2, Circle, Loader2, Plus
} from 'lucide-react';

interface Props {
  recipe: RecipeResponse;
  onReset: () => void;
}

const RecipeCard: React.FC<Props> = ({ recipe, onReset }) => {
  // Timer State
  const [timeLeft, setTimeLeft] = useState(0); // in seconds
  const [isActive, setIsActive] = useState(false);
  const [initialTime, setInitialTime] = useState(0);
  const [customMinutes, setCustomMinutes] = useState('');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  
  // Audio ref for alarm
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio
    audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
  }, []);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      setIsActive(false);
      // Play sound
      audioRef.current?.play().catch((e) => console.log("Audio play failed", e));
      alert("Dring! Il timer è scaduto! 🍽️");
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const toggleTimer = () => setIsActive(!isActive);
  
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(initialTime);
  };
  
  const setPresetTimer = (minutes: number) => {
    setIsActive(false);
    setInitialTime(minutes * 60);
    setTimeLeft(minutes * 60);
  };

  const handleCustomTimeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const mins = parseInt(customMinutes);
    if (!isNaN(mins) && mins > 0) {
      setPresetTimer(mins);
      setCustomMinutes('');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Calculate progress percentage for visual bar
  const progressPercent = initialTime > 0 ? (timeLeft / initialTime) * 100 : 0;

  const handlePrint = () => {
    window.print();
  };

  const handlePdf = () => {
    const element = document.getElementById('printable-recipe');
    if (!element) return;

    // @ts-ignore
    if (typeof window !== 'undefined' && window.html2pdf) {
      setIsGeneratingPdf(true);
      const opt = {
        margin:       [10, 10],
        filename:     `${recipe.recipeName.replace(/ /g, '_')}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true, letterRendering: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
      };

      // @ts-ignore
      window.html2pdf().set(opt).from(element).save().then(() => {
        setIsGeneratingPdf(false);
      }).catch((err: any) => {
        console.error("PDF Error:", err);
        setIsGeneratingPdf(false);
        // Fallback to print if library fails
        alert("Impossibile generare il PDF direttamente. Si aprirà la finestra di stampa.");
        window.print();
      });
    } else {
      // Fallback
      window.print();
    }
  };
  
  // Ingredients checklist state
  const [checkedIngredients, setCheckedIngredients] = useState<string[]>([]);
  const toggleIngredient = (ing: string) => {
    if (checkedIngredients.includes(ing)) {
      setCheckedIngredients(checkedIngredients.filter(i => i !== ing));
    } else {
      setCheckedIngredients([...checkedIngredients, ing]);
    }
  };

  return (
    <div id="printable-recipe" className="max-w-4xl mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden animate-slide-up pb-10 print:shadow-none print:max-w-none print:w-full">
      {/* Hero Image Section */}
      <div className="relative h-72 md:h-96 w-full group print:h-64">
        {/* Added crossOrigin anonymous to allow html2canvas to read the image data */}
        <img 
          src={`https://image.pollinations.ai/prompt/professional food photography of ${encodeURIComponent(recipe.recipeName)}, michelin star plating, cinematic lighting, 4k, hyperrealistic, warm atmosphere?width=1200&height=800&model=flux&nologo=true`} 
          alt={recipe.recipeName}
          crossOrigin="anonymous"
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
        />
        
        {/* Dark Gradient Overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent print:opacity-50"></div>
        
        {/* Navigation - Hidden on Print */}
        <button 
          onClick={onReset}
          className="absolute top-6 left-6 bg-white/20 hover:bg-white/40 backdrop-blur-md text-white p-2 rounded-full transition-all border border-white/30 z-20 print:hidden"
          aria-label="Torna indietro"
        >
          <ArrowLeft size={24} />
        </button>

        {/* Title Section (Bottom of Hero) */}
        <div className="absolute bottom-0 left-0 w-full p-8 text-white z-10 print:text-black print:p-4">
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-3 leading-tight drop-shadow-lg print:text-black print:drop-shadow-none">
            {recipe.recipeName}
          </h2>
          <div className="flex flex-wrap gap-3 text-sm md:text-base font-sans opacity-95 font-medium print:text-gray-800">
             <span className="flex items-center gap-1.5 bg-black/40 px-4 py-1.5 rounded-full backdrop-blur-md border border-white/20 shadow-sm print:bg-transparent print:border-gray-300 print:text-black print:p-0">
               <Clock size={18} className="text-nonno-200 print:text-black" /> {recipe.prepTimeMinutes} min
             </span>
             <span className="flex items-center gap-1.5 bg-black/40 px-4 py-1.5 rounded-full backdrop-blur-md border border-white/20 shadow-sm print:bg-transparent print:border-gray-300 print:text-black print:p-0 print:hidden">
               <ChefHat size={18} className="text-nonno-200" /> NonnoWeb Original
             </span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 md:p-10 space-y-10 print:p-6 print:space-y-6">
        
        {/* Description & Tip */}
        <div className="space-y-8 print:space-y-4">
          <p className="text-xl md:text-2xl text-gray-600 italic font-serif leading-relaxed border-l-4 border-nonno-500 pl-6 py-1 print:text-lg">
            "{recipe.description}"
          </p>

          {/* Nonno's Tip Card */}
          <div className="bg-gradient-to-br from-yellow-50 to-orange-50 border border-nonno-200 rounded-2xl p-6 relative overflow-hidden shadow-sm print:bg-white print:border-gray-300 print:p-4">
             <div className="absolute -right-6 -top-6 text-nonno-200 opacity-50 rotate-12 print:hidden">
               <Sparkles size={120} />
             </div>
             <h4 className="flex items-center gap-2 text-nonno-800 font-bold mb-3 relative z-10 text-lg print:text-black">
               <Sparkles size={24} className="text-nonno-600 fill-nonno-600 print:text-black" /> 
               Il consiglio del Nonno
             </h4>
             <p className="text-nonno-900 relative z-10 font-medium text-lg leading-relaxed print:text-black">
               {recipe.nonnoTip}
             </p>
          </div>
        </div>

        <div className="grid md:grid-cols-12 gap-10 print:block">
          
          {/* Left Column: Ingredients & Wine (5 cols) */}
          <div className="md:col-span-5 space-y-8 print:mb-6">
            
            {/* Ingredients */}
            <div>
              <h3 className="text-2xl font-serif font-bold text-gray-800 mb-5 flex items-center gap-3 border-b border-gray-100 pb-2 print:text-xl print:mb-3">
                <span>🛒</span> La Spesa
              </h3>
              <ul className="space-y-3 print:grid print:grid-cols-2 print:gap-2 print:space-y-0">
                {recipe.ingredientsList.map((ing, idx) => {
                  const isChecked = checkedIngredients.includes(ing);
                  return (
                    <li 
                      key={idx} 
                      onClick={() => toggleIngredient(ing)}
                      className={`
                        group flex items-start gap-3 p-3 rounded-xl cursor-pointer transition-all border select-none
                        ${isChecked 
                          ? 'bg-green-50 border-green-200 shadow-none' 
                          : 'bg-white border-gray-100 hover:border-nonno-200 shadow-sm hover:shadow-md'}
                        print:border-0 print:p-1 print:shadow-none print:bg-transparent
                      `}
                    >
                      <div className={`mt-0.5 shrink-0 transition-colors ${isChecked ? 'text-green-600' : 'text-gray-300 group-hover:text-nonno-500'} print:text-black`}>
                        {isChecked ? <CheckCircle2 size={22} className="fill-green-100 print:hidden" /> : <Circle size={22} className="print:w-4 print:h-4" />}
                      </div>
                      <span className={`transition-all ${isChecked ? 'text-gray-400 line-through' : 'text-gray-700 font-medium'} print:text-black print:no-underline`}>
                        {ing}
                      </span>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Wine Pairing */}
            <div className="bg-purple-50 rounded-2xl p-6 border border-purple-100 shadow-inner print:bg-white print:border print:border-gray-200 print:p-4 print:mt-4">
               <h3 className="text-purple-900 font-bold mb-3 flex items-center gap-2 text-lg print:text-black">
                 <Wine className="text-purple-600 print:text-black" /> L'abbinamento
               </h3>
               <p className="text-purple-900/80 italic font-medium leading-relaxed print:text-black">
                 {recipe.winePairing}
               </p>
            </div>

          </div>

          {/* Right Column: Steps & Timer (7 cols) */}
          <div className="md:col-span-7 space-y-10 print:space-y-6">
            
            {/* Steps */}
            <div>
              <h3 className="text-2xl font-serif font-bold text-gray-800 mb-6 flex items-center gap-3 border-b border-gray-100 pb-2 print:text-xl print:mb-3">
                <span>🍳</span> Procedimento
              </h3>
              <div className="space-y-8 print:space-y-4">
                {recipe.steps.map((step, idx) => (
                  <div key={idx} className="flex gap-4 group print:gap-2">
                    <div className="flex-shrink-0 w-10 h-10 bg-nonno-100 text-nonno-700 rounded-full flex items-center justify-center font-bold font-serif text-xl border border-nonno-200 shadow-sm group-hover:bg-nonno-500 group-hover:text-white transition-colors print:w-8 print:h-8 print:text-base print:bg-transparent print:border-black print:text-black">
                      {idx + 1}
                    </div>
                    <p className="text-gray-700 leading-relaxed pt-1 text-lg print:text-base print:text-black">
                      {step}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Kitchen Timer Widget - Hidden on Print */}
            <div 
              className={`
                text-white rounded-3xl p-6 shadow-xl border-4 relative overflow-hidden transition-all duration-500 print:hidden
                ${isActive 
                  ? 'bg-stone-800 border-nonno-500 shadow-nonno-500/30' 
                  : 'bg-stone-800 border-stone-700/50'}
              `}
            >
               {/* Background shine effect */}
               <div className={`absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl -mr-10 -mt-10 transition-colors duration-700 ${isActive ? 'bg-nonno-500/20' : 'bg-white/5'}`}></div>
               
               <div className="relative z-10">
                 <div className="flex flex-col xl:flex-row items-center justify-between mb-8 gap-4">
                   <h4 className={`flex items-center gap-2 font-bold text-lg transition-colors ${isActive ? 'text-nonno-400' : 'text-stone-300'}`}>
                     <Clock className={isActive ? 'text-nonno-400' : 'text-stone-500'} /> Timer
                   </h4>
                   
                   <div className="flex flex-wrap items-center justify-center gap-2 bg-stone-900/50 p-1.5 rounded-xl">
                     {/* Presets */}
                     {[5, 10, 15].map(min => (
                       <button 
                         key={min}
                         onClick={() => setPresetTimer(min)}
                         className="text-sm font-bold bg-stone-700 hover:bg-nonno-600 hover:text-white px-3 py-1.5 rounded-lg transition-colors text-gray-300 min-w-[3rem]"
                       >
                         {min}m
                       </button>
                     ))}
                     
                     {/* Divider */}
                     <div className="w-px h-6 bg-stone-600 mx-1"></div>

                     {/* Custom Input */}
                     <form onSubmit={handleCustomTimeSubmit} className="flex items-center gap-1">
                       <input 
                         type="number" 
                         placeholder="min"
                         min="1"
                         max="180"
                         value={customMinutes}
                         onChange={(e) => setCustomMinutes(e.target.value)}
                         className="w-12 bg-stone-700 text-white text-sm text-center py-1.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-nonno-500 placeholder:text-gray-500"
                       />
                       <button 
                         type="submit"
                         disabled={!customMinutes}
                         className="bg-stone-700 hover:bg-nonno-600 text-white p-1.5 rounded-lg disabled:opacity-50 disabled:hover:bg-stone-700 transition-colors"
                       >
                         <Plus size={16} />
                       </button>
                     </form>
                   </div>
                 </div>
                 
                 <div className="text-center mb-8 relative">
                   <div className={`text-7xl font-mono font-bold tracking-widest tabular-nums transition-all duration-500 ${isActive ? 'text-nonno-300 drop-shadow-[0_0_15px_rgba(253,224,71,0.3)]' : 'text-stone-500'}`}>
                     {formatTime(timeLeft)}
                   </div>
                 </div>

                 <div className="flex justify-center gap-6 mb-2">
                    {isActive ? (
                      <button onClick={toggleTimer} className="bg-red-500 hover:bg-red-600 text-white w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-105 hover:shadow-lg hover:shadow-red-500/30">
                        <Pause fill="currentColor" size={28} />
                      </button>
                    ) : (
                      <button onClick={toggleTimer} disabled={timeLeft === 0} className="disabled:opacity-50 disabled:cursor-not-allowed bg-green-500 hover:bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-105 hover:shadow-lg hover:shadow-green-500/30">
                        <Play fill="currentColor" className="ml-1" size={28} />
                      </button>
                    )}
                    <button onClick={resetTimer} className="bg-stone-600 hover:bg-stone-500 text-white w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-105 hover:shadow-lg">
                      <RotateCcw size={24} />
                    </button>
                 </div>
                 
                 {/* Progress Bar */}
                 {initialTime > 0 && (
                   <div className="mt-6 h-1.5 w-full bg-stone-700 rounded-full overflow-hidden">
                     <div 
                       className={`h-full transition-all duration-1000 ease-linear ${isActive ? 'bg-nonno-500' : 'bg-stone-500'}`}
                       style={{ width: `${progressPercent}%` }}
                     ></div>
                   </div>
                 )}
               </div>
            </div>

          </div>
        </div>

        {/* Footer Actions - Hidden on Print */}
        <div className="border-t border-gray-100 pt-8 mt-4 flex flex-col sm:flex-row gap-4 justify-between items-center print:hidden">
          <button 
             onClick={onReset}
             className="text-gray-500 hover:text-nonno-600 font-bold flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-nonno-50 transition-colors w-full sm:w-auto justify-center"
          >
            <ArrowLeft size={20} /> Torna alla dispensa
          </button>
          
          <div className="flex gap-3 w-full sm:w-auto">
            <button 
              onClick={handlePrint}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-bold transition-colors"
            >
              <Printer size={20} /> <span className="hidden sm:inline">Stampa</span>
            </button>
            <button 
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-nonno-600 hover:bg-nonno-700 text-white rounded-xl font-bold transition-all shadow-lg hover:shadow-nonno-200/50 disabled:opacity-70 disabled:cursor-not-allowed"
              onClick={handlePdf}
              disabled={isGeneratingPdf}
            >
              {isGeneratingPdf ? <Loader2 className="animate-spin" size={20} /> : <Download size={20} />}
              <span className="hidden sm:inline">Salva PDF</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

export default RecipeCard;