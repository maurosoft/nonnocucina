import { GoogleGenAI, Type, Schema } from "@google/genai";
import { RecipeRequest, RecipeResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const recipeSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    recipeName: { type: Type.STRING, description: "Il nome creativo e italiano della ricetta" },
    description: { type: Type.STRING, description: "Una breve descrizione appetitosa" },
    ingredientsList: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Lista completa degli ingredienti con quantità stimate"
    },
    steps: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Passaggi passo dopo passo per cucinare"
    },
    winePairing: { type: Type.STRING, description: "Un vino specifico consigliato per questo piatto" },
    nonnoTip: { type: Type.STRING, description: "Un consiglio segreto o un detto saggio di NonnoWeb" },
    prepTimeMinutes: { type: Type.INTEGER, description: "Tempo di preparazione stimato in minuti" }
  },
  required: ["recipeName", "description", "ingredientsList", "steps", "winePairing", "nonnoTip", "prepTimeMinutes"]
};

export const generateRecipe = async (request: RecipeRequest): Promise<RecipeResponse> => {
  const ingredients = [...request.selectedIngredients];
  if (request.customIngredients.trim()) {
    ingredients.push(request.customIngredients);
  }

  const courseInstruction = request.courseType === 'sorpresa' 
    ? "un piatto che stia bene con gli ingredienti" 
    : `assolutamente un ${request.courseType}`;

  const prompt = `
    Sei NonnoWeb, un anziano cuoco italiano saggio, caldo e accogliente. 
    Parla come un nonno affettuoso ma esperto.
    
    Crea una ricetta basata su questi ingredienti: ${ingredients.join(", ")}.
    
    Richiesta Specifica: Devi creare ${courseInstruction}. 
    Se l'utente ha chiesto un DOLCE, devi fare un dolce anche se gli ingredienti sono strani (sii creativo).
    Se l'utente ha chiesto un PRIMO, deve essere pasta, riso, zuppa o simili.
    Se l'utente ha chiesto un SECONDO, deve essere carne, pesce, uova o vegetariano sostanzioso.
    
    È per un ${request.mealType} per ${request.peopleCount} persone.
    
    Attenzione alle seguenti intolleranze/allergie: ${request.intolerances || "Nessuna"}.
    
    Se mancano ingredienti fondamentali (come sale, olio, acqua, zucchero, farina), assumi che siano presenti in casa, ma cerca di usare principalmente quelli forniti.
    Il tono deve essere incoraggiante e rustico.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: recipeSchema,
        temperature: 0.7, 
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Nessuna risposta generata da NonnoWeb.");
    }

    return JSON.parse(text) as RecipeResponse;
  } catch (error) {
    console.error("Errore nella generazione della ricetta:", error);
    throw error;
  }
};